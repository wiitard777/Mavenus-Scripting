package dagannoths;

import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.task.TaskContainer;

public interface MyContainer extends TaskContainer {

	}
